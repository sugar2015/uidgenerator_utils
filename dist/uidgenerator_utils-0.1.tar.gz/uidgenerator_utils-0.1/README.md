1. Add "uidgenerator" to your INSTALLED_APPS setting like this:
    INSTALLED_APPS = (
        ...
        'uidgenerator',
    )
